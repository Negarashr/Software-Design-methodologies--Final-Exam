package ca.concordia.soen6461.decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;

public class Hat extends AbstractDecorator {
	
	 public Hat(ICharacter decoratedchar) {
	        super(decoratedchar);
	    }
	    @Override
	    protected ICharacter hat(ICharacter character) {
			character.setDress(" hatOn ");
			return character;
	    }


}
