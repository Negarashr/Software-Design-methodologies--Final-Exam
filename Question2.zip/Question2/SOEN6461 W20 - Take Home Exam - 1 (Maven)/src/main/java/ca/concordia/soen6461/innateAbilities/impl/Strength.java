package ca.concordia.soen6461.innateAbilities.impl;

import java.util.HashMap;

import ca.concordia.soen6461.innateAbilities.InnateAbilities;
import ca.concordia.soen6461.visitor.Ivisitor;

public class Strength implements InnateAbilities{
	public static HashMap<String, Integer> valueMap  = new HashMap<String, Integer>() {{
	    put("burly", 10);
	    put("fit", 9);
	    put("scrawny", 8);
	    put("plump", 7);
	    
	}};
	
	
	private String myGivenStringValue;
	private int myGivenIntValue;
	public Strength(String mgsv)
	{
		if (Strength.valueMap.containsKey(mgsv.toLowerCase()))
		{
			this.myGivenStringValue=mgsv.toLowerCase();
		}
		
	}
	
	
	public int findMyGivenIntValue()
	{
		myGivenIntValue=valueMap.get(myGivenStringValue);
		//System.out.println("findint is ok");
		return myGivenIntValue;
		
	}
	
	 public void accept(Ivisitor visitor, String newValue) {
		 
	        visitor.addToMap(this, newValue);
//	    	for (Map.Entry<String, Integer> pair: this.valueMap.entrySet()) 
//			{
//				System.out.println(pair.getKey());
//				System.out.println(pair.getValue());
//			}
	    }

}
