package ca.concordia.soen6461.decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;

public class Helmet extends AbstractDecorator{
	
	 public Helmet(ICharacter decoratedchar) {
	        super(decoratedchar);
	    }
	 	@Override
	    protected ICharacter helmet(ICharacter character) {
	 		character.setDress(" helmetOn ");
	        return character;
	    }

}
