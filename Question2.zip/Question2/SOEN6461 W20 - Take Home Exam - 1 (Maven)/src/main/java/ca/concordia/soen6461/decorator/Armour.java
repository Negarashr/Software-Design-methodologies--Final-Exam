package ca.concordia.soen6461.decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;

public class Armour extends AbstractDecorator{
	
	
	 public Armour(ICharacter decoratedchar) {
	        super(decoratedchar);
	    }
	 	@Override
	    protected ICharacter armour(ICharacter character) {
	 		character.setDress("armourOn");
	        return character;
	    }
}
