package ca.concordia.soen6461.decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;

public class Cloak extends AbstractDecorator {

	public Cloak(ICharacter decoratedChar) {
		super(decoratedChar);
		
	}
	@Override
    protected ICharacter cloak(ICharacter character) {
 		character.setDress(" cloakOn ");
        return character;
    }

}
