package ca.concordia.soen6461.innateAbilities.impl;

import java.util.HashMap;

import ca.concordia.soen6461.innateAbilities.InnateAbilities;
import ca.concordia.soen6461.visitor.Ivisitor;

public class Dexterity implements InnateAbilities{
	public static HashMap<String, Integer> valueMap  = new HashMap<String, Integer>() {{
	    put("slim", 10);
	    put("sneaky", 9);
	    put("awkward", 8);
	    put("clumsy", 7);
	    
	}};


	private String myGivenStringValue;
	private int myGivenIntValue;
	public Dexterity(String mgsv)
	{
		if (Dexterity.valueMap.containsKey(mgsv.toLowerCase()))
		{
			this.myGivenStringValue=mgsv.toLowerCase();
		}
		
	}
	
	
	public int findMyGivenIntValue()
	{
		myGivenIntValue=valueMap.get(myGivenStringValue);
	
		return myGivenIntValue;
		
	}
	
	 public void accept(Ivisitor visitor, String newValue) {
		 
	        visitor.addToMap(this, newValue);

	    }


}
