package ca.concordia.soen6461.characterclasses;

public abstract class AbstractCharacter implements ICharacter{

	@Override
	public abstract int getStrength();

	@Override
	public abstract int getDexterity();
	@Override
	public abstract int getConstitution();

	@Override
	public abstract int getIntelligence();

	@Override
	public abstract int getWisdom();

	@Override
	public abstract int getCharisma();
	

}
