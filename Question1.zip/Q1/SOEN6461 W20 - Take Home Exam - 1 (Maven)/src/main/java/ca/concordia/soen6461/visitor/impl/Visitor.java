package ca.concordia.soen6461.visitor.impl;

import java.util.Map;
import java.util.Random;

import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Constitution;
import ca.concordia.soen6461.innateAbilities.impl.Dexterity;
import ca.concordia.soen6461.innateAbilities.impl.Intelligence;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.innateAbilities.impl.Wisdom;
import ca.concordia.soen6461.visitor.Ivisitor;

public class Visitor implements Ivisitor {

	
	public Visitor()
	{
	}
	public void addToMap(Strength strength, String newValue)
	{
		Random r=new Random();
		Strength.valueMap.put(newValue,r.nextInt(7));
	}


	public void addToMap(Constitution constitution, String newValue)
	{
		Random r=new Random();
		Constitution.valueMap.put(newValue,r.nextInt(7));
		
	}


	public void addToMap(Dexterity dexterity, String newValue) 
	{
		Random r=new Random();
		Dexterity.valueMap.put(newValue,r.nextInt(7));
		
	}

	
	public void addToMap(Intelligence intelligence, String newValue) 
	{
		Random r=new Random();
		Intelligence.valueMap.put(newValue,r.nextInt(7));
		
	}

	
	public void addToMap(Wisdom wisdom, String newValue) 
	{
		Random r=new Random();
		Wisdom.valueMap.put(newValue,r.nextInt(7));
	}


	public void addToMap(Charisma charisma, String newValue)
	{
		Random r=new Random();
		Charisma.valueMap.put(newValue,r.nextInt(7));
			
	}

}
