package ca.concordia.soen6461.characterclasses.impl;

import ca.concordia.soen6461.characterclasses.AbstractCharacter;
import ca.concordia.soen6461.characterclasses.IRanger;
import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Constitution;
import ca.concordia.soen6461.innateAbilities.impl.Dexterity;
import ca.concordia.soen6461.innateAbilities.impl.Intelligence;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.innateAbilities.impl.Wisdom;

public class Ranger extends AbstractCharacter implements IRanger {


	private Strength strength  ;
	private Dexterity dexterity;

	private Constitution constitution;
	private Intelligence intelligence;
	private Wisdom wisdom;
	private Charisma charisma;
	
	
	 public Ranger(String strength,String dexterity,String constitution , String intelligence, String wisdom, String charisma ) 
	 {
	      this.strength = new Strength(strength);
	      this.dexterity = new Dexterity(dexterity);
	      this.constitution= new Constitution(constitution);
	      this.intelligence = new Intelligence(intelligence);
	      this.wisdom = new Wisdom(wisdom);
	      this.charisma = new Charisma(charisma);


	 }
	

	@Override
	public int getStrength() {
		return this.strength.findMyGivenIntValue();
	}

	@Override
	public int getDexterity() {
		return this.dexterity.findMyGivenIntValue();
	}

	@Override
	public int getConstitution() {
		return this.constitution.findMyGivenIntValue();
	}

	@Override
	public int getIntelligence() {
		return this.intelligence.findMyGivenIntValue();
	}

	@Override
	public int getWisdom() {
		return this.wisdom.findMyGivenIntValue();
	}

	@Override
	public int getCharisma() {
		return this.charisma.findMyGivenIntValue();
	}


}
