package ca.concordia.soen6461.innateAbilities;

public interface InnateAbilities {

}
