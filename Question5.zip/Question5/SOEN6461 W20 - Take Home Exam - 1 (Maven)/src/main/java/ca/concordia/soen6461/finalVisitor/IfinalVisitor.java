package ca.concordia.soen6461.finalVisitor;

import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Constitution;
import ca.concordia.soen6461.innateAbilities.impl.Dexterity;
import ca.concordia.soen6461.innateAbilities.impl.Intelligence;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.innateAbilities.impl.Wisdom;

public interface IfinalVisitor {
	
    public void addToStrength (Strength strength);
    public void addToConstitution(Constitution constitution);
    public void addToDexterity (Dexterity dexterity);
    public void addToIntelligence (Intelligence intelligence);
    public void addToWisdom (Wisdom wisdom);
    public void addToCharisma (Charisma charisma);

	
}
