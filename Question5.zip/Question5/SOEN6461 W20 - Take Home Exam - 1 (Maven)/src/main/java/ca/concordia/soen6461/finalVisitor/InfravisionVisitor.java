package ca.concordia.soen6461.finalVisitor;

import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Constitution;
import ca.concordia.soen6461.innateAbilities.impl.Dexterity;
import ca.concordia.soen6461.innateAbilities.impl.Intelligence;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.innateAbilities.impl.Wisdom;

public class InfravisionVisitor implements IfinalVisitor{

	
	public void addToStrength(Strength strength) {
		
		System.out.println("Infravision adds 2 to Strength ");
		strength.myGivenIntValue+=2;
		
	}

	
	public void addToConstitution(Constitution constitution) {
		constitution.myGivenIntValue+=2;
		
	}

	
	public void addToDexterity(Dexterity dexterity) {
		dexterity.myGivenIntValue+=2;
		
	}

	@Override
	public void addToIntelligence(Intelligence intelligence) {
		intelligence.myGivenIntValue+=2;
		
	}

	@Override
	public void addToWisdom(Wisdom wisdom) {
		wisdom.myGivenIntValue+=2;
		
	}

	@Override
	public void addToCharisma(Charisma charisma) {
		charisma.myGivenIntValue+=2;
		
	}
	

}
