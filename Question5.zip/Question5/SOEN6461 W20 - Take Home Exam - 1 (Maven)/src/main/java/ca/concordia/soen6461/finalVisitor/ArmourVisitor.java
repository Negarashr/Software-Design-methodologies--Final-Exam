package ca.concordia.soen6461.finalVisitor;

import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Constitution;
import ca.concordia.soen6461.innateAbilities.impl.Dexterity;
import ca.concordia.soen6461.innateAbilities.impl.Intelligence;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.innateAbilities.impl.Wisdom;

public class ArmourVisitor implements IfinalVisitor{

	
	public void addToStrength(Strength strength) {
		
		System.out.println("Armour adds 7 to Strength ");
		strength.myGivenIntValue+=7;
		
	}

	
	public void addToConstitution(Constitution constitution) {
		constitution.myGivenIntValue+=4;
		
	}

	
	public void addToDexterity(Dexterity dexterity) {
		dexterity.myGivenIntValue+=4;
		
	}

	@Override
	public void addToIntelligence(Intelligence intelligence) {
		intelligence.myGivenIntValue+=1;
		
	}

	@Override
	public void addToWisdom(Wisdom wisdom) {
		wisdom.myGivenIntValue+=3;
		
	}

	@Override
	public void addToCharisma(Charisma charisma) {
		charisma.myGivenIntValue+=2;
		
	}
	

}



