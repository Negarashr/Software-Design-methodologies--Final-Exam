package ca.concordia.soen6461.powers;

public interface PowersToPossess {

}
