package ca.concordia.soen6461.decorator;

import java.util.List;

import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.composite.ItemsToCarry;
import ca.concordia.soen6461.powers.PowersToPossess;

public class AbstractDecorator implements ICharacter {
    private final ICharacter decorated;
 //   private String s;

    public AbstractDecorator(ICharacter decoratedChar) {
        this.decorated = decoratedChar;
    }

    protected ICharacter boots(ICharacter character) {
        
        return character;
    }

    protected ICharacter hat(ICharacter bootsOn) {
       
        return bootsOn;
    }
    protected ICharacter helmet(ICharacter hatOn) {
   
        return hatOn;
    }
    protected ICharacter cloak(ICharacter helmetOn) {
        return helmetOn;
    }
    protected ICharacter armour(ICharacter cloakOn) {
        return cloakOn;
    }

    public final String wearClothes (ICharacter character){
        final ICharacter bootsOn = this.boots(character);
        final ICharacter hatOn = this.hat(bootsOn);
        final ICharacter helmetsOn = this.helmet(hatOn);
        final ICharacter cloakOn = this.cloak(helmetsOn);
        final ICharacter armourOn = this.armour(cloakOn);
        return decorated.getDress();
    }

    @Override
    public void setDress(String dress) {
        decorated.setDress(dress);
    }

    @Override
    public String getDress() {
        return decorated.getDress();
    }

    @Override
    public int getStrength() {
        return decorated.getStrength();
    }

    @Override
    public int getDexterity() {
        return decorated.getDexterity();
    }

    @Override
    public int getConstitution() {
        return decorated.getConstitution();
    }

    @Override
    public int getIntelligence() {
        return decorated.getIntelligence();
    }

    @Override
    public int getWisdom() {
        return decorated.getWisdom();
    }

    @Override
    public int getCharisma() {
        return decorated.getCharisma();
    }

	@Override
	public void setItems(List<List<ItemsToCarry>> items) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void setPowers(List<PowersToPossess> powers) {
		// TODO Auto-generated method stub
		
	}


}
