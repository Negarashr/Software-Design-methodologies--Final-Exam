/* (c) Copyright 2020 and following years, Yann-Gaël Guéhéneuc,
 * Concordia University.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package ca.concordia.soen6461.client;

import java.util.ArrayList;
import java.util.List;

import ca.concordia.soen6461.characterclasses.IBarbarian;
import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.IRanger;
import ca.concordia.soen6461.characterclasses.impl.Factory;
import ca.concordia.soen6461.composite.Book;
import ca.concordia.soen6461.composite.Box;
import ca.concordia.soen6461.composite.Food;
import ca.concordia.soen6461.composite.GoldCoin;
import ca.concordia.soen6461.composite.IContainer;
import ca.concordia.soen6461.composite.ItemsToCarry;
import ca.concordia.soen6461.composite.MagicalRing;
import ca.concordia.soen6461.composite.Satchel;
import ca.concordia.soen6461.decorator.Armour;
import ca.concordia.soen6461.decorator.Hat;
import ca.concordia.soen6461.decorator.Helmet;
import ca.concordia.soen6461.finalVisitor.BootsVisitor;
import ca.concordia.soen6461.finalVisitor.BoxVisitor;
import ca.concordia.soen6461.finalVisitor.CloakVisitor;
import ca.concordia.soen6461.finalVisitor.HatVisitor;
import ca.concordia.soen6461.finalVisitor.IfinalVisitor;
import ca.concordia.soen6461.finalVisitor.InfravisionVisitor;
import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.powers.Infravision;
import ca.concordia.soen6461.powers.PowersToPossess;
import ca.concordia.soen6461.powers.Spell;
import ca.concordia.soen6461.visitor.Ivisitor;
import ca.concordia.soen6461.visitor.impl.Visitor;

public class Client {
	public static void main(final String[] args) {
		
		IBarbarian barbar2 = new Factory().createBarbarian("burly","slim","sick","forgetful","oblivious","awkward");
		// I assume that I am having a barbarian with infravision power and a box and a hat and a cloak and boot I want to calculate the total strength
		Strength s=new Strength("burly");
		int x=s.findMyGivenIntValue();
		System.out.println("Strength innitial value:"+s.myGivenIntValue);
		IfinalVisitor visitor= new InfravisionVisitor();
		IfinalVisitor visitor1= new BoxVisitor();
		IfinalVisitor visitor2= new HatVisitor();
		IfinalVisitor visitor3= new CloakVisitor();
		IfinalVisitor visitor4= new BootsVisitor();
		s.accept(visitor);
		s.accept(visitor1);
		s.accept(visitor2);
		s.accept(visitor3);
		s.accept(visitor4);
		System.out.println(s.myGivenIntValue);
	}
}
