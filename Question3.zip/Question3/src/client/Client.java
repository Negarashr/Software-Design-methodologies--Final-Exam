package client;

import java.util.List;

import composite.Book;
import composite.Box;
import composite.Food;
import composite.GoldCoin;
import composite.IContainer;
import composite.ItemsToCarry;
import composite.MagicalRing;
import composite.Satchel;


public class Client {

	public static void main(String[] args) {
		IContainer satchel=new Satchel("satchel1");
		IContainer box=new Box("Box1");
		Food food1=new Food("burger");
		Book book1 =new Book("harry potter book");
		GoldCoin coin1= new GoldCoin("oldCoin");
		MagicalRing ring1= new MagicalRing("invisible Ring");
		box.addItemToContainer(coin1);
		box.addItemToContainer(ring1);
		
		satchel.addItemToContainer(book1);
		satchel.addItemToContainer(food1);
		satchel.addItemToContainer(coin1);
		box.addItemToContainer(food1);
		List<ItemsToCarry> listOfBox= box.getList();
		System.out.println("inside box:");
		for(ItemsToCarry item: listOfBox)
		{
			System.out.println(item.getName());
		}
		List<ItemsToCarry> listOfSatchel= satchel.getList();
		System.out.println("inside satchel:");
		for(ItemsToCarry item: listOfSatchel)
		{
			System.out.println(item.getName());
		}
		
	

	}

}
