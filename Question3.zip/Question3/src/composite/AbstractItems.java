package composite;

public abstract class AbstractItems implements IContainer{
	

}
