package composite;

public class MagicalRing extends Box implements ItemsToCarry {
	
	private String Name;
	
	public MagicalRing(String name)
	{
		super(name);
		this.Name=name;
	}
	
	public String getName()
	{
		return this.Name;
	}

}
