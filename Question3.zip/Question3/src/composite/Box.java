package composite;

import java.util.ArrayList;
import java.util.List;

public class Box extends AbstractItems implements IContainer{
	
	private String Name;
	private List<ItemsToCarry> list=new ArrayList<ItemsToCarry>();


	public Box(String name)
	{
		this.Name=name;
	}
	public void addItemToContainer(ItemsToCarry item)
	{
	
		if(item instanceof Box )
		{
			this.list.add(item);
			System.out.println(item.getName()+" is stored in Box");

		}
		else 
		{
			System.out.println("you cannot put "+item.getName()+" in Box");
		}
	}
	
	public List<ItemsToCarry> getList()
	{
		return this.list;
	}

	public String getName() {
		return this.Name;
	}
	

}
