package composite;

public class GoldCoin extends Box implements ItemsToCarry {
	
	private String Name;
	
	public GoldCoin (String name)
	{
		super(name);
		this.Name=name;
	}
	
	public String getName()
	{
		return this.Name;
	}

}
