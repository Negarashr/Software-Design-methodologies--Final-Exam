package composite;

public class Book extends Satchel implements ItemsToCarry {
	
	private String Name;
	
	public Book(String name)
	{
		super(name);
		this.Name=name;
	}
	
	public String getName()
	{
		return this.Name;
	}

}
