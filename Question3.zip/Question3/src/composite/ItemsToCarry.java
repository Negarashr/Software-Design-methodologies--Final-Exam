package composite;

public interface ItemsToCarry {
	public String getName();
	
}
