package composite;

public class Food extends Satchel implements ItemsToCarry{
	
	private String Name;
	
	public Food(String name)
	{
		super(name);
		this.Name=name;
	}
	
	public String getName()
	{
		return this.Name;
	}
	

}
