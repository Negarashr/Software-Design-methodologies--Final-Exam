package ca.concordia.soen6461.composite;

import java.util.List;

public interface ItemsToCarry {
	public String getName();
	public List<ItemsToCarry> getList();
	
}
