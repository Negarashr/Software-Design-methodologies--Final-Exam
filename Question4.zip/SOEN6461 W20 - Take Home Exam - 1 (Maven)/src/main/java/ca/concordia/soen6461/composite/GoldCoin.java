package ca.concordia.soen6461.composite;

public class GoldCoin extends Box  {
	
	private String Name;
	
	public GoldCoin (String name)
	{
		super(name);
		this.Name=name;
	}
	
	public String getName()
	{
		return this.Name;
	}

}
