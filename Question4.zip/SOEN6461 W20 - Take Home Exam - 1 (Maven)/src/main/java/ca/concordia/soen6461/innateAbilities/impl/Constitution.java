package ca.concordia.soen6461.innateAbilities.impl;

import java.util.HashMap;

import ca.concordia.soen6461.innateAbilities.InnateAbilities;
import ca.concordia.soen6461.visitor.Ivisitor;

public class Constitution implements InnateAbilities {
	public static HashMap<String, Integer> valueMap  = new HashMap<String, Integer>() {{
	    put("strong", 10);
	    put("healthy", 9);
	    put("frail", 8);
	    put("sick", 7);
	    
	}};

	private String myGivenStringValue;
	private int myGivenIntValue;
	public Constitution(String mgsv)
	{
		if (Charisma.valueMap.containsKey(mgsv.toLowerCase()))
		{
			this.myGivenStringValue=mgsv.toLowerCase();
		}
		
	}
	
	
	public int findMyGivenIntValue()
	{
		myGivenIntValue=valueMap.get(myGivenStringValue);
		//System.out.println("findint is ok");
		return myGivenIntValue;
		
	}
	
	 public void accept(Ivisitor visitor, String newValue) {
		 
	        visitor.addToMap(this, newValue);
//	    	for (Map.Entry<String, Integer> pair: this.valueMap.entrySet()) 
//			{
//				System.out.println(pair.getKey());
//				System.out.println(pair.getValue());
//			}
	    }

}
