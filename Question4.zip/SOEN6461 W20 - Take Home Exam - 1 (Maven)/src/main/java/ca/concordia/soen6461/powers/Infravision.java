package ca.concordia.soen6461.powers;

public class Infravision implements PowersToPossess{
	
	private String Name;
	public Infravision(String name)
	{
		this.Name=name;
	}
	
	

}
