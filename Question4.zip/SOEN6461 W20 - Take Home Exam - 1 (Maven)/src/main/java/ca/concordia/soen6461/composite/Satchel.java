package ca.concordia.soen6461.composite;

import java.util.ArrayList;
import java.util.List;

public class Satchel extends AbstractItems implements IContainer {
	
	private String Name;
	private List<ItemsToCarry> list=new ArrayList<ItemsToCarry>();
	
	public Satchel(String name)
	{
		Name=name;
	}
	public void addItemToContainer(ItemsToCarry item)
	{
	
		if(item instanceof Satchel )
		{
			this.list.add(item);
			System.out.println(item.getName()+" is stored in satchel");

		}
		else 
		{
			System.out.println("you cannot put "+item.getName()+" in satchel");
		}
	}
	
	public List<ItemsToCarry> getList()
	{
		return this.list;
	}

	
	public String getName() {
		
		return Name;
	}
	
	

}
