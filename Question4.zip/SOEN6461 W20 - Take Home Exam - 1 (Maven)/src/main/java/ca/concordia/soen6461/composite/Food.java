package ca.concordia.soen6461.composite;

public class Food extends Satchel{
	
	private String Name;
	
	public Food(String name)
	{
		super(name);
		this.Name=name;
	}
	
	public String getName()
	{
		return this.Name;
	}
	

}
