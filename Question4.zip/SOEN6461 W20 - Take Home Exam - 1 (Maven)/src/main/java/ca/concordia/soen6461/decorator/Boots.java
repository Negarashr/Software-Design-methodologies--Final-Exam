package ca.concordia.soen6461.decorator;

import ca.concordia.soen6461.characterclasses.ICharacter;

public class Boots extends AbstractDecorator {

	 public Boots(ICharacter decoratedchar) {
	        super(decoratedchar);
	    }
	 	@Override
	    protected ICharacter boots(ICharacter character) {
	 		character.setDress(" bootsOn ");
	        return character;
	    }
}
