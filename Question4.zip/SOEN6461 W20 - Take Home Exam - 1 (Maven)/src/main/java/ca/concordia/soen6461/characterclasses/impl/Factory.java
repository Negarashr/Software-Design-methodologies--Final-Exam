package ca.concordia.soen6461.characterclasses.impl;

import ca.concordia.soen6461.characterclasses.IBarbarian;
import ca.concordia.soen6461.characterclasses.IDruid;
import ca.concordia.soen6461.characterclasses.IRanger;
import ca.concordia.soen6461.characterclasses.IWizard;

public class Factory {
	
	
	
	  public IBarbarian createBarbarian (String strength,String dexterity,String constitution , String intelligence, String wisdom, String charisma )
	  {

	        return new Barbarian(strength, dexterity, constitution , intelligence, wisdom, charisma);
	  }
	  public IDruid createDruid (String strength,String dexterity,String constitution , String intelligence, String wisdom, String charisma )
	  {

	        return new Druid(strength, dexterity, constitution , intelligence, wisdom, charisma);
	  }
	  
	  public IRanger createRanger (String strength,String dexterity,String constitution , String intelligence, String wisdom, String charisma )
	  {

	        return new Ranger(strength, dexterity, constitution , intelligence, wisdom, charisma);
	  }
	  
	  public IWizard createWizard (String strength,String dexterity,String constitution , String intelligence, String wisdom, String charisma )
	  {

	        return new Wizard(strength, dexterity, constitution , intelligence, wisdom, charisma);
	  }
	  
	  
}
