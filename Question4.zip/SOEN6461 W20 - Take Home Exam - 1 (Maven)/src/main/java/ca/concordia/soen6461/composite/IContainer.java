package ca.concordia.soen6461.composite;

import java.util.List;

public interface IContainer extends ItemsToCarry {
	
	void addItemToContainer(ItemsToCarry item);
	List<ItemsToCarry> getList();

}
