/* (c) Copyright 2020 and following years, Yann-Gaël Guéhéneuc,
 * Concordia University.
 * 
 * Use and copying of this software and preparation of derivative works
 * based upon this software are permitted. Any copy of this software or
 * of any derivative work must include the above copyright notice of
 * the author, this paragraph and the one after it.
 * 
 * This software is made available AS IS, and THE AUTHOR DISCLAIMS
 * ALL WARRANTIES, EXPRESS OR IMPLIED, INCLUDING WITHOUT LIMITATION THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE, AND NOT WITHSTANDING ANY OTHER PROVISION CONTAINED HEREIN,
 * ANY LIABILITY FOR DAMAGES RESULTING FROM THE SOFTWARE OR ITS USE IS
 * EXPRESSLY DISCLAIMED, WHETHER ARISING IN CONTRACT, TORT (INCLUDING
 * NEGLIGENCE) OR STRICT LIABILITY, EVEN IF THE AUTHOR IS ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGES.
 * 
 * All Rights Reserved.
 */
package ca.concordia.soen6461.client;

import java.util.ArrayList;
import java.util.List;

import ca.concordia.soen6461.characterclasses.IBarbarian;
import ca.concordia.soen6461.characterclasses.ICharacter;
import ca.concordia.soen6461.characterclasses.IRanger;
import ca.concordia.soen6461.characterclasses.impl.Factory;
import ca.concordia.soen6461.composite.Book;
import ca.concordia.soen6461.composite.Box;
import ca.concordia.soen6461.composite.Food;
import ca.concordia.soen6461.composite.GoldCoin;
import ca.concordia.soen6461.composite.IContainer;
import ca.concordia.soen6461.composite.ItemsToCarry;
import ca.concordia.soen6461.composite.MagicalRing;
import ca.concordia.soen6461.composite.Satchel;
import ca.concordia.soen6461.decorator.Armour;
import ca.concordia.soen6461.decorator.Hat;
import ca.concordia.soen6461.decorator.Helmet;
import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.powers.Infravision;
import ca.concordia.soen6461.powers.PowersToPossess;
import ca.concordia.soen6461.powers.Spell;
import ca.concordia.soen6461.visitor.Ivisitor;
import ca.concordia.soen6461.visitor.impl.Visitor;

public class Client {
	public static void main(final String[] args) {
		
		IContainer satchel=new Satchel("satchel1");
		IContainer box=new Box("Box1");
		Food food1=new Food("burger");
		Book book1 =new Book("harry potter");
		GoldCoin coin1= new GoldCoin("oldCoin");
		MagicalRing ring1= new MagicalRing("invisible Ring");
		Infravision infravision1=new Infravision("infravision");
		Spell spell1=new Spell("Spell");
		
		
		//List<ItemsToCarry> listOfBox= box.getList();
		satchel.addItemToContainer(book1);
		satchel.addItemToContainer(food1);
		satchel.addItemToContainer(coin1);
		box.addItemToContainer(food1);
		List<ItemsToCarry> listOfBox= box.getList();
		

		List<ItemsToCarry> listOfSatchel= satchel.getList();
		
		List<List<ItemsToCarry>> listOfAllItems=new ArrayList<List<ItemsToCarry>>();
		listOfAllItems.add(listOfSatchel);
		listOfAllItems.add(listOfBox);
		List<PowersToPossess> listOfPowers=new ArrayList<PowersToPossess>();
		listOfPowers.add(spell1);
		listOfPowers.add(infravision1);
		IBarbarian barbar2 = new Factory().createBarbarian("burly","slim","sick","forgetful","oblivious","awkward");
		barbar2.setItems(listOfAllItems);
		barbar2.setPowers(listOfPowers);
	
	}
}
