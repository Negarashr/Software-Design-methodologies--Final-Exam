package ca.concordia.soen6461.innateAbilities.impl;

import java.util.HashMap;

import ca.concordia.soen6461.innateAbilities.InnateAbilities;
import ca.concordia.soen6461.visitor.Ivisitor;

public class Wisdom implements InnateAbilities {

	public static HashMap<String, Integer> valueMap  = new HashMap<String, Integer>() {{
	    put("good judgement", 10);
	    put("empathy", 9);
	    put("foolish", 8);
	    put("oblivious", 7);
	    
	}};
	

	private String myGivenStringValue;
	private int myGivenIntValue;
	public Wisdom(String mgsv)
	{
		if (Charisma.valueMap.containsKey(mgsv.toLowerCase()))
		{
			this.myGivenStringValue=mgsv.toLowerCase();
		}
		
	}
	
	
	public int findMyGivenIntValue()
	{
		myGivenIntValue=valueMap.get(myGivenStringValue);
	
		return myGivenIntValue;
		
	}
	
	 public void accept(Ivisitor visitor, String newValue) 
	 {
		 
	        visitor.addToMap(this, newValue);

	 }

}
