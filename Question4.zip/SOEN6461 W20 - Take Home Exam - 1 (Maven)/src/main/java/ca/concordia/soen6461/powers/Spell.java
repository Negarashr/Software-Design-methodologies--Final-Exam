package ca.concordia.soen6461.powers;

public class Spell implements PowersToPossess {
	
	private String Name;
	public Spell(String name)
	{
		this.Name=name;
	}
	

}
