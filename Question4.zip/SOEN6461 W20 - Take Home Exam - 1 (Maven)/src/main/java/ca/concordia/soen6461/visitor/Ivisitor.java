package ca.concordia.soen6461.visitor;

import ca.concordia.soen6461.innateAbilities.impl.Charisma;
import ca.concordia.soen6461.innateAbilities.impl.Constitution;
import ca.concordia.soen6461.innateAbilities.impl.Dexterity;
import ca.concordia.soen6461.innateAbilities.impl.Intelligence;
import ca.concordia.soen6461.innateAbilities.impl.Strength;
import ca.concordia.soen6461.innateAbilities.impl.Wisdom;

public interface Ivisitor {

    public void addToMap (Strength strength, String newValue);
    public void addToMap (Constitution constitution, String newValue);
    public void addToMap (Dexterity dexterity, String newValue);
    public void addToMap (Intelligence intelligence, String newValue);
    public void addToMap (Wisdom wisdom, String newValue);
    public void addToMap (Charisma charisma, String newValue);
}
