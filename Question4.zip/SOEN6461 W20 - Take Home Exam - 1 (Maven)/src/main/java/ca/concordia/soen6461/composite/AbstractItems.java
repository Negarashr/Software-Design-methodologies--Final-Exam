package ca.concordia.soen6461.composite;

public abstract class AbstractItems implements IContainer{
	

}
