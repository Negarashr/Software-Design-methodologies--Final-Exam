package ca.concordia.soen6461.innateAbilities;

import ca.concordia.soen6461.visitor.Ivisitor;

public interface InnateAbilities {
	void accept(Ivisitor visitor, String newValue); 

}
