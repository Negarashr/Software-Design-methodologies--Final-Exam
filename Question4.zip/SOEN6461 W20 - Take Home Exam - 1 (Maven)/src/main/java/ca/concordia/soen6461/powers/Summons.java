package ca.concordia.soen6461.powers;

public class Summons implements PowersToPossess{

	private String Name;
	public Summons(String name)
	{
		this.Name=name;
	}
	
}
